// Course_1 Saturday  Conditions ========================================================

if(Course_1_Time == 9.30 && Course_1_Day == Saturday){
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}


else if(Course_1_Time == 9.30 && Course_1_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}
else if(Course_1_Time == 10.30 && Course_1_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 11.30 && Course_1_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 12.30 && Course_1_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 1.30 && Course_1_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 2.30 && Course_1_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 3.30 && Course_1_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}






// Course_1 Sunday  Conditions ========================================================

if(Course_1_Time == 9.30 && Course_1_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}


else if(Course_1_Time == 9.30 && Course_1_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}
else if(Course_1_Time == 10.30 && Course_1_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 11.30 && Course_1_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 12.30 && Course_1_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 1.30 && Course_1_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 2.30 && Course_1_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 3.30 && Course_1_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}










// Course_1 Monday  Conditions ========================================================

if(Course_1_Time == 9.30 && Course_1_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}


else if(Course_1_Time == 9.30 && Course_1_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}
else if(Course_1_Time == 10.30 && Course_1_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 11.30 && Course_1_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 12.30 && Course_1_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 1.30 && Course_1_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 2.30 && Course_1_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 3.30 && Course_1_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}







// Course_1 Tuesday  Conditions ========================================================

if(Course_1_Time == 9.30 && Course_1_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}


else if(Course_1_Time == 9.30 && Course_1_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}
else if(Course_1_Time == 10.30 && Course_1_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 11.30 && Course_1_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 12.30 && Course_1_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 1.30 && Course_1_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 2.30 && Course_1_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 3.30 && Course_1_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}






// Course_1 Wednessday  Conditions ========================================================

if(Course_1_Time == 9.30 && Course_1_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}


else if(Course_1_Time == 9.30 && Course_1_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}
else if(Course_1_Time == 10.30 && Course_1_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 11.30 && Course_1_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 12.30 && Course_1_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 1.30 && Course_1_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 2.30 && Course_1_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 3.30 && Course_1_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}







// Course_1 Thursday  Conditions ========================================================

if(Course_1_Time == 9.30 && Course_1_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}


else if(Course_1_Time == 9.30 && Course_1_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}
else if(Course_1_Time == 10.30 && Course_1_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 11.30 && Course_1_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 12.30 && Course_1_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 1.30 && Course_1_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 2.30 && Course_1_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}

else if(Course_1_Time == 3.30 && Course_1_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_1_Name + "<br><br>" + 
    Course_1_Teacher + "<br><br>" + 
    Course_1_RoomNo + "<hr>";
}







// Course_2 Saturday  Conditions ========================================================

if(Course_2_Time == 8.30 && Course_2_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}


else if(Course_2_Time == 9.30 && Course_2_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}
else if(Course_2_Time == 10.30 && Course_2_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 11.30 && Course_2_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 12.30 && Course_2_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 1.30 && Course_2_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 2.30 && Course_2_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 3.30 && Course_2_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}









// Course_2 Sunday  Conditions ========================================================

if(Course_2_Time == 9.30 && Course_2_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}


else if(Course_2_Time == 9.30 && Course_2_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}
else if(Course_2_Time == 10.30 && Course_2_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 11.30 && Course_2_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 12.30 && Course_2_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 1.30 && Course_2_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 2.30 && Course_2_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 3.30 && Course_2_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}







// Course_2 Monday  Conditions ========================================================

if(Course_2_Time == 9.30 && Course_2_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}


else if(Course_2_Time == 9.30 && Course_2_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}
else if(Course_2_Time == 10.30 && Course_2_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 11.30 && Course_2_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 12.30 && Course_2_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 1.30 && Course_2_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 2.30 && Course_2_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 3.30 && Course_2_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}




// Course_2 Tuesday  Conditions ========================================================

if(Course_2_Time == 9.30 && Course_2_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}


else if(Course_2_Time == 9.30 && Course_2_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}
else if(Course_2_Time == 10.30 && Course_2_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 11.30 && Course_2_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 12.30 && Course_2_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 1.30 && Course_2_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 2.30 && Course_2_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 3.30 && Course_2_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}




// Course_2 Wednessday  Conditions ========================================================

if(Course_2_Time == 9.30 && Course_2_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}


else if(Course_2_Time == 9.30 && Course_2_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}
else if(Course_2_Time == 10.30 && Course_2_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 11.30 && Course_2_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 12.30 && Course_2_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 1.30 && Course_2_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 2.30 && Course_2_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 3.30 && Course_2_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}






// Course_2 Thursday  Conditions ========================================================

if(Course_2_Time == 9.30 && Course_2_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}


else if(Course_2_Time == 9.30 && Course_2_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}
else if(Course_2_Time == 10.30 && Course_2_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 11.30 && Course_2_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 12.30 && Course_2_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 1.30 && Course_2_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 2.30 && Course_2_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}

else if(Course_2_Time == 3.30 && Course_2_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_2_Name + "<br><br>" + 
    Course_2_Teacher + "<br><br>" + 
    Course_2_RoomNo + "<hr>";
}






// Course_3 Saturday  Conditions ========================================================

if(Course_3_Time == 8.30 && Course_3_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}


else if(Course_3_Time == 9.30 && Course_3_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}
else if(Course_3_Time == 10.30 && Course_3_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 11.30 && Course_3_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 12.30 && Course_3_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 1.30 && Course_3_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 2.30 && Course_3_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 3.30 && Course_3_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}








// Course_3 Sunday  Conditions ========================================================

if(Course_3_Time == 9.30 && Course_3_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}


else if(Course_3_Time == 9.30 && Course_3_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}
else if(Course_3_Time == 10.30 && Course_3_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 11.30 && Course_3_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 12.30 && Course_3_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 1.30 && Course_3_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 2.30 && Course_3_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 3.30 && Course_3_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}




// Course_3 Monday  Conditions ========================================================

if(Course_3_Time == 9.30 && Course_3_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}


else if(Course_3_Time == 9.30 && Course_3_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}
else if(Course_3_Time == 10.30 && Course_3_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 11.30 && Course_3_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 12.30 && Course_3_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 1.30 && Course_3_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 2.30 && Course_3_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 3.30 && Course_3_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}





// Course_3 Tuesday  Conditions ========================================================

if(Course_3_Time == 9.30 && Course_3_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}


else if(Course_3_Time == 9.30 && Course_3_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}
else if(Course_3_Time == 10.30 && Course_3_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 11.30 && Course_3_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 12.30 && Course_3_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 1.30 && Course_3_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 2.30 && Course_3_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 3.30 && Course_3_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}






// Course_3 Wednessday  Conditions ========================================================

if(Course_3_Time == 9.30 && Course_3_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}


else if(Course_3_Time == 9.30 && Course_3_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}
else if(Course_3_Time == 10.30 && Course_3_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 11.30 && Course_3_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 12.30 && Course_3_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 1.30 && Course_3_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 2.30 && Course_3_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 3.30 && Course_3_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}






// Course_3 Thursday  Conditions ========================================================

if(Course_3_Time == 9.30 && Course_3_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}


else if(Course_3_Time == 9.30 && Course_3_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}
else if(Course_3_Time == 10.30 && Course_3_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 11.30 && Course_3_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 12.30 && Course_3_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 1.30 && Course_3_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 2.30 && Course_3_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}

else if(Course_3_Time == 3.30 && Course_3_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_3_Name + "<br><br>" + 
    Course_3_Teacher + "<br><br>" + 
    Course_3_RoomNo + "<hr>";
}





// Course_4 Saturday  Conditions ========================================================

if(Course_4_Time == 8.30 && Course_4_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}


else if(Course_4_Time == 9.30 && Course_4_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}
else if(Course_4_Time == 10.30 && Course_4_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 11.30 && Course_4_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 12.30 && Course_4_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 1.30 && Course_4_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 2.30 && Course_4_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 3.30 && Course_4_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}





// Course_4 Sunday  Conditions ========================================================

if(Course_4_Time == 9.30 && Course_4_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}


else if(Course_4_Time == 9.30 && Course_4_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}
else if(Course_4_Time == 10.30 && Course_4_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 11.30 && Course_4_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 12.30 && Course_4_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 1.30 && Course_4_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 2.30 && Course_4_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 3.30 && Course_4_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}




// Course_4 Monday  Conditions ========================================================

if(Course_4_Time == 9.30 && Course_4_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}


else if(Course_4_Time == 9.30 && Course_4_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}
else if(Course_4_Time == 10.30 && Course_4_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 11.30 && Course_4_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 12.30 && Course_4_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 1.30 && Course_4_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 2.30 && Course_4_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 3.30 && Course_4_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}







// Course_4 Tuesday  Conditions ========================================================

if(Course_4_Time == 9.30 && Course_4_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}


else if(Course_4_Time == 9.30 && Course_4_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}
else if(Course_4_Time == 10.30 && Course_4_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 11.30 && Course_4_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 12.30 && Course_4_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 1.30 && Course_4_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 2.30 && Course_4_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 3.30 && Course_4_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}









// Course_4 Wednessday  Conditions ========================================================

if(Course_4_Time == 9.30 && Course_4_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}


else if(Course_4_Time == 9.30 && Course_4_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}
else if(Course_4_Time == 10.30 && Course_4_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 11.30 && Course_4_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 12.30 && Course_4_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 1.30 && Course_4_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 2.30 && Course_4_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 3.30 && Course_4_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}











// Course_4 Thursday  Conditions ========================================================

if(Course_4_Time == 9.30 && Course_4_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}


else if(Course_4_Time == 9.30 && Course_4_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}
else if(Course_4_Time == 10.30 && Course_4_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 11.30 && Course_4_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 12.30 && Course_4_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 1.30 && Course_4_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 2.30 && Course_4_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}

else if(Course_4_Time == 3.30 && Course_4_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_4_Name + "<br><br>" + 
    Course_4_Teacher + "<br><br>" + 
    Course_4_RoomNo + "<hr>";
}








// Course_5 Saturday  Conditions ========================================================

if(Course_5_Time == 8.30 && Course_5_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}


else if(Course_5_Time == 9.30 && Course_5_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}
else if(Course_5_Time == 10.30 && Course_5_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 11.30 && Course_5_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 12.30 && Course_5_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 1.30 && Course_5_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 2.30 && Course_5_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 3.30 && Course_5_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

















// Course_5 Sunday  Conditions ========================================================

if(Course_5_Time == 9.30 && Course_5_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}


else if(Course_5_Time == 9.30 && Course_5_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}
else if(Course_5_Time == 10.30 && Course_5_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 11.30 && Course_5_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 12.30 && Course_5_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 1.30 && Course_5_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 2.30 && Course_5_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 3.30 && Course_5_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}





// Course_5 Monday  Conditions ========================================================

if(Course_5_Time == 9.30 && Course_5_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}


else if(Course_5_Time == 9.30 && Course_5_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}
else if(Course_5_Time == 10.30 && Course_5_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 11.30 && Course_5_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 12.30 && Course_5_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 1.30 && Course_5_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 2.30 && Course_5_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 3.30 && Course_5_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}













// Course_5 Tuesday  Conditions ========================================================

if(Course_5_Time == 9.30 && Course_5_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}


else if(Course_5_Time == 9.30 && Course_5_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}
else if(Course_5_Time == 10.30 && Course_5_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 11.30 && Course_5_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 12.30 && Course_5_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 1.30 && Course_5_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 2.30 && Course_5_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 3.30 && Course_5_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}









// Course_5 Wednessday  Conditions ========================================================

if(Course_5_Time == 9.30 && Course_5_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}


else if(Course_5_Time == 9.30 && Course_5_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}
else if(Course_5_Time == 10.30 && Course_5_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 11.30 && Course_5_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 12.30 && Course_5_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 1.30 && Course_5_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 2.30 && Course_5_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 3.30 && Course_5_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}











// Course_5 Thursday  Conditions ========================================================

if(Course_5_Time == 9.30 && Course_5_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}


else if(Course_5_Time == 9.30 && Course_5_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}
else if(Course_5_Time == 10.30 && Course_5_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 11.30 && Course_5_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 12.30 && Course_5_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 1.30 && Course_5_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 2.30 && Course_5_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}

else if(Course_5_Time == 3.30 && Course_5_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_5_Name + "<br><br>" + 
    Course_5_Teacher + "<br><br>" + 
    Course_5_RoomNo + "<hr>";
}














// Course_6 Saturday  Conditions ========================================================

if(Course_6_Time == 8.30 && Course_6_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}


else if(Course_6_Time == 9.30 && Course_6_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}
else if(Course_6_Time == 10.30 && Course_6_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 11.30 && Course_6_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 12.30 && Course_6_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 1.30 && Course_6_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 2.30 && Course_6_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 3.30 && Course_6_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}






// Course_6 Sunday  Conditions ========================================================

if(Course_6_Time == 9.30 && Course_6_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}


else if(Course_6_Time == 9.30 && Course_6_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}
else if(Course_6_Time == 10.30 && Course_6_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 11.30 && Course_6_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 12.30 && Course_6_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 1.30 && Course_6_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 2.30 && Course_6_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 3.30 && Course_6_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}










// Course_6 Monday  Conditions ========================================================

if(Course_6_Time == 9.30 && Course_6_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}


else if(Course_6_Time == 9.30 && Course_6_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}
else if(Course_6_Time == 10.30 && Course_6_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 11.30 && Course_6_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 12.30 && Course_6_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 1.30 && Course_6_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 2.30 && Course_6_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 3.30 && Course_6_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}













// Course_6 Tuesday  Conditions ========================================================

if(Course_6_Time == 9.30 && Course_6_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}


else if(Course_6_Time == 9.30 && Course_6_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}
else if(Course_6_Time == 10.30 && Course_6_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 11.30 && Course_6_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 12.30 && Course_6_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 1.30 && Course_6_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 2.30 && Course_6_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 3.30 && Course_6_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}









// Course_6 Wednessday  Conditions ========================================================

if(Course_6_Time == 9.30 && Course_6_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}


else if(Course_6_Time == 9.30 && Course_6_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}
else if(Course_6_Time == 10.30 && Course_6_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 11.30 && Course_6_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 12.30 && Course_6_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 1.30 && Course_6_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 2.30 && Course_6_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 3.30 && Course_6_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}











// Course_6 Thursday  Conditions ========================================================

if(Course_6_Time == 9.30 && Course_6_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}


else if(Course_6_Time == 9.30 && Course_6_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}
else if(Course_6_Time == 10.30 && Course_6_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 11.30 && Course_6_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 12.30 && Course_6_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 1.30 && Course_6_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 2.30 && Course_6_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}

else if(Course_6_Time == 3.30 && Course_6_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_6_Name + "<br><br>" + 
    Course_6_Teacher + "<br><br>" + 
    Course_6_RoomNo + "<hr>";
}








// Course_7 Saturday  Conditions ========================================================

if(Course_7_Time == 8.30 && Course_7_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}


else if(Course_7_Time == 9.30 && Course_7_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}
else if(Course_7_Time == 10.30 && Course_7_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 11.30 && Course_7_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 12.30 && Course_7_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 1.30 && Course_7_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 2.30 && Course_7_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 3.30 && Course_7_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

















// Course_7 Sunday  Conditions ========================================================

if(Course_7_Time == 9.30 && Course_7_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}


else if(Course_7_Time == 9.30 && Course_7_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}
else if(Course_7_Time == 10.30 && Course_7_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 11.30 && Course_7_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 12.30 && Course_7_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 1.30 && Course_7_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 2.30 && Course_7_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 3.30 && Course_7_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}










// Course_7 Monday  Conditions ========================================================

if(Course_7_Time == 9.30 && Course_7_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}


else if(Course_7_Time == 9.30 && Course_7_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}
else if(Course_7_Time == 10.30 && Course_7_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 11.30 && Course_7_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 12.30 && Course_7_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 1.30 && Course_7_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 2.30 && Course_7_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 3.30 && Course_7_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}













// Course_7 Tuesday  Conditions ========================================================

if(Course_7_Time == 9.30 && Course_7_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}


else if(Course_7_Time == 9.30 && Course_7_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}
else if(Course_7_Time == 10.30 && Course_7_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 11.30 && Course_7_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 12.30 && Course_7_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 1.30 && Course_7_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 2.30 && Course_7_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 3.30 && Course_7_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}









// Course_7 Wednessday  Conditions ========================================================

if(Course_7_Time == 9.30 && Course_7_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}


else if(Course_7_Time == 9.30 && Course_7_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}
else if(Course_7_Time == 10.30 && Course_7_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 11.30 && Course_7_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 12.30 && Course_7_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 1.30 && Course_7_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 2.30 && Course_7_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 3.30 && Course_7_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}











// Course_7 Thursday  Conditions ========================================================

if(Course_7_Time == 9.30 && Course_7_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}


else if(Course_7_Time == 9.30 && Course_7_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}
else if(Course_7_Time == 10.30 && Course_7_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 11.30 && Course_7_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 12.30 && Course_7_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 1.30 && Course_7_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 2.30 && Course_7_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}

else if(Course_7_Time == 3.30 && Course_7_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_7_Name + "<br><br>" + 
    Course_7_Teacher + "<br><br>" + 
    Course_7_RoomNo + "<hr>";
}






// Course_8 Saturday  Conditions ========================================================

if(Course_8_Time == 8.30 && Course_8_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}


else if(Course_8_Time == 9.30 && Course_8_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}
else if(Course_8_Time == 10.30 && Course_8_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 11.30 && Course_8_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 12.30 && Course_8_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 1.30 && Course_8_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 2.30 && Course_8_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 3.30 && Course_8_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

















// Course_8 Sunday  Conditions ========================================================

if(Course_8_Time == 9.30 && Course_8_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}


else if(Course_8_Time == 9.30 && Course_8_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}
else if(Course_8_Time == 10.30 && Course_8_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 11.30 && Course_8_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 12.30 && Course_8_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 1.30 && Course_8_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 2.30 && Course_8_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 3.30 && Course_8_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}










// Course_8 Monday  Conditions ========================================================

if(Course_8_Time == 9.30 && Course_8_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}


else if(Course_8_Time == 9.30 && Course_8_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}
else if(Course_8_Time == 10.30 && Course_8_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 11.30 && Course_8_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 12.30 && Course_8_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 1.30 && Course_8_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 2.30 && Course_8_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 3.30 && Course_8_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}













// Course_8 Tuesday  Conditions ========================================================

if(Course_8_Time == 9.30 && Course_8_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}


else if(Course_8_Time == 9.30 && Course_8_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}
else if(Course_8_Time == 10.30 && Course_8_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 11.30 && Course_8_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 12.30 && Course_8_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 1.30 && Course_8_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 2.30 && Course_8_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 3.30 && Course_8_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}









// Course_8 Wednessday  Conditions ========================================================

if(Course_8_Time == 9.30 && Course_8_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}


else if(Course_8_Time == 9.30 && Course_8_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}
else if(Course_8_Time == 10.30 && Course_8_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 11.30 && Course_8_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 12.30 && Course_8_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 1.30 && Course_8_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 2.30 && Course_8_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 3.30 && Course_8_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}











// Course_8 Thursday  Conditions ========================================================

if(Course_8_Time == 9.30 && Course_8_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}


else if(Course_8_Time == 9.30 && Course_8_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}
else if(Course_8_Time == 10.30 && Course_8_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 11.30 && Course_8_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 12.30 && Course_8_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 1.30 && Course_8_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 2.30 && Course_8_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}

else if(Course_8_Time == 3.30 && Course_8_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_8_Name + "<br><br>" + 
    Course_8_Teacher + "<br><br>" + 
    Course_8_RoomNo + "<hr>";
}







// Course_9 Saturday  Conditions ========================================================

if(Course_9_Time == 8.30 && Course_9_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}


else if(Course_9_Time == 9.30 && Course_9_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}
else if(Course_9_Time == 10.30 && Course_9_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 11.30 && Course_9_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 12.30 && Course_9_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 1.30 && Course_9_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 2.30 && Course_9_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 3.30 && Course_9_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

















// Course_9 Sunday  Conditions ========================================================

if(Course_9_Time == 9.30 && Course_9_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}


else if(Course_9_Time == 9.30 && Course_9_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}
else if(Course_9_Time == 10.30 && Course_9_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 11.30 && Course_9_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 12.30 && Course_9_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 1.30 && Course_9_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 2.30 && Course_9_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 3.30 && Course_9_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}










// Course_9 Monday  Conditions ========================================================

if(Course_9_Time == 9.30 && Course_9_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}


else if(Course_9_Time == 9.30 && Course_9_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}
else if(Course_9_Time == 10.30 && Course_9_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 11.30 && Course_9_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 12.30 && Course_9_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 1.30 && Course_9_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 2.30 && Course_9_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 3.30 && Course_9_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}













// Course_9 Tuesday  Conditions ========================================================

if(Course_9_Time == 9.30 && Course_9_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}


else if(Course_9_Time == 9.30 && Course_9_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}
else if(Course_9_Time == 10.30 && Course_9_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 11.30 && Course_9_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 12.30 && Course_9_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 1.30 && Course_9_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 2.30 && Course_9_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 3.30 && Course_9_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}









// Course_9 Wednessday  Conditions ========================================================

if(Course_9_Time == 9.30 && Course_9_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}


else if(Course_9_Time == 9.30 && Course_9_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}
else if(Course_9_Time == 10.30 && Course_9_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 11.30 && Course_9_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 12.30 && Course_9_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 1.30 && Course_9_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 2.30 && Course_9_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 3.30 && Course_9_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}











// Course_9 Thursday  Conditions ========================================================

if(Course_9_Time == 9.30 && Course_9_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}


else if(Course_9_Time == 9.30 && Course_9_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}
else if(Course_9_Time == 10.30 && Course_9_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 11.30 && Course_9_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 12.30 && Course_9_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 1.30 && Course_9_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 2.30 && Course_9_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}

else if(Course_9_Time == 3.30 && Course_9_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_9_Name + "<br><br>" + 
    Course_9_Teacher + "<br><br>" + 
    Course_9_RoomNo + "<hr>";
}






// Course_10 Saturday  Conditions ========================================================

if(Course_10_Time == 8.30 && Course_10_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}


else if(Course_10_Time == 9.30 && Course_10_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}
else if(Course_10_Time == 10.30 && Course_10_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 11.30 && Course_10_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 12.30 && Course_10_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 1.30 && Course_10_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 2.30 && Course_10_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 3.30 && Course_10_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

















// Course_10 Sunday  Conditions ========================================================

if(Course_10_Time == 9.30 && Course_10_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}


else if(Course_10_Time == 9.30 && Course_10_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}
else if(Course_10_Time == 10.30 && Course_10_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 11.30 && Course_10_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 12.30 && Course_10_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 1.30 && Course_10_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 2.30 && Course_10_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 3.30 && Course_10_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}










// Course_10 Monday  Conditions ========================================================

if(Course_10_Time == 9.30 && Course_10_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}


else if(Course_10_Time == 9.30 && Course_10_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}
else if(Course_10_Time == 10.30 && Course_10_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 11.30 && Course_10_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 12.30 && Course_10_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 1.30 && Course_10_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 2.30 && Course_10_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 3.30 && Course_10_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}













// Course_10 Tuesday  Conditions ========================================================

if(Course_10_Time == 9.30 && Course_10_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}


else if(Course_10_Time == 9.30 && Course_10_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}
else if(Course_10_Time == 10.30 && Course_10_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 11.30 && Course_10_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 12.30 && Course_10_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 1.30 && Course_10_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 2.30 && Course_10_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 3.30 && Course_10_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}









// Course_10 Wednessday  Conditions ========================================================

if(Course_10_Time == 9.30 && Course_10_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}


else if(Course_10_Time == 9.30 && Course_10_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}
else if(Course_10_Time == 10.30 && Course_10_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 11.30 && Course_10_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 12.30 && Course_10_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 1.30 && Course_10_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 2.30 && Course_10_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 3.30 && Course_10_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}











// Course_10 Thursday  Conditions ========================================================

if(Course_10_Time == 9.30 && Course_10_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}


else if(Course_10_Time == 9.30 && Course_10_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}
else if(Course_10_Time == 10.30 && Course_10_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 11.30 && Course_10_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 12.30 && Course_10_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 1.30 && Course_10_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 2.30 && Course_10_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}

else if(Course_10_Time == 3.30 && Course_10_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_10_Name + "<br><br>" + 
    Course_10_Teacher + "<br><br>" + 
    Course_10_RoomNo + "<hr>";
}







// Course_11 Saturday  Conditions ========================================================

if(Course_11_Time == 8.30 && Course_11_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}


else if(Course_11_Time == 9.30 && Course_11_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}
else if(Course_11_Time == 10.30 && Course_11_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 11.30 && Course_11_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 12.30 && Course_11_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 1.30 && Course_11_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 2.30 && Course_11_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 3.30 && Course_11_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

















// Course_11 Sunday  Conditions ========================================================

if(Course_11_Time == 9.30 && Course_11_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}


else if(Course_11_Time == 9.30 && Course_11_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}
else if(Course_11_Time == 10.30 && Course_11_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 11.30 && Course_11_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 12.30 && Course_11_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 1.30 && Course_11_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 2.30 && Course_11_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 3.30 && Course_11_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}










// Course_11 Monday  Conditions ========================================================

if(Course_11_Time == 9.30 && Course_11_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}


else if(Course_11_Time == 9.30 && Course_11_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}
else if(Course_11_Time == 10.30 && Course_11_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 11.30 && Course_11_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 12.30 && Course_11_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 1.30 && Course_11_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 2.30 && Course_11_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 3.30 && Course_11_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}













// Course_11 Tuesday  Conditions ========================================================

if(Course_11_Time == 9.30 && Course_11_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}


else if(Course_11_Time == 9.30 && Course_11_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}
else if(Course_11_Time == 10.30 && Course_11_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 11.30 && Course_11_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 12.30 && Course_11_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 1.30 && Course_11_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 2.30 && Course_11_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 3.30 && Course_11_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}









// Course_11 Wednessday  Conditions ========================================================

if(Course_11_Time == 9.30 && Course_11_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}


else if(Course_11_Time == 9.30 && Course_11_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}
else if(Course_11_Time == 10.30 && Course_11_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 11.30 && Course_11_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 12.30 && Course_11_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 1.30 && Course_11_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 2.30 && Course_11_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 3.30 && Course_11_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}











// Course_11 Thursday  Conditions ========================================================

if(Course_11_Time == 9.30 && Course_11_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}


else if(Course_11_Time == 9.30 && Course_11_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}
else if(Course_11_Time == 10.30 && Course_11_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 11.30 && Course_11_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 12.30 && Course_11_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 1.30 && Course_11_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 2.30 && Course_11_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}

else if(Course_11_Time == 3.30 && Course_11_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_11_Name + "<br><br>" + 
    Course_11_Teacher + "<br><br>" + 
    Course_11_RoomNo + "<hr>";
}






// Course_12 Saturday  Conditions ========================================================

if(Course_12_Time == 8.30 && Course_12_Day == Saturday){
    document.getElementById("Saturday-8.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}


else if(Course_12_Time == 9.30 && Course_12_Day == Saturday){
    
    document.getElementById("Saturday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}
else if(Course_12_Time == 10.30 && Course_12_Day == Saturday){

    document.getElementById("Saturday-10.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 11.30 && Course_12_Day == Saturday){

    document.getElementById("Saturday-11.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 12.30 && Course_12_Day == Saturday){

    document.getElementById("Saturday-12.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 1.30 && Course_12_Day == Saturday){

    document.getElementById("Saturday-1.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 2.30 && Course_12_Day == Saturday){

    document.getElementById("Saturday-2.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 3.30 && Course_12_Day == Saturday){

    document.getElementById("Saturday-3.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

















// Course_12 Sunday  Conditions ========================================================

if(Course_12_Time == 9.30 && Course_12_Day == Sunday){
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}


else if(Course_12_Time == 9.30 && Course_12_Day == Sunday){
    
    document.getElementById("Sunday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}
else if(Course_12_Time == 10.30 && Course_12_Day == Sunday){

    document.getElementById("Sunday-10.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 11.30 && Course_12_Day == Sunday){

    document.getElementById("Sunday-11.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 12.30 && Course_12_Day == Sunday){

    document.getElementById("Sunday-12.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 1.30 && Course_12_Day == Sunday){

    document.getElementById("Sunday-1.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 2.30 && Course_12_Day == Sunday){

    document.getElementById("Sunday-2.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 3.30 && Course_12_Day == Sunday){

    document.getElementById("Sunday-3.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}










// Course_12 Monday  Conditions ========================================================

if(Course_12_Time == 9.30 && Course_12_Day == Monday){
    document.getElementById("Monday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}


else if(Course_12_Time == 9.30 && Course_12_Day == Monday){
    
    document.getElementById("Monday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}
else if(Course_12_Time == 10.30 && Course_12_Day == Monday){

    document.getElementById("Monday-10.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 11.30 && Course_12_Day == Monday){

    document.getElementById("Monday-11.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 12.30 && Course_12_Day == Monday){

    document.getElementById("Monday-12.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 1.30 && Course_12_Day == Monday){

    document.getElementById("Monday-1.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 2.30 && Course_12_Day == Monday){

    document.getElementById("Monday-2.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 3.30 && Course_12_Day == Monday){

    document.getElementById("Monday-3.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}













// Course_12 Tuesday  Conditions ========================================================

if(Course_12_Time == 9.30 && Course_12_Day == Tuesday){
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}


else if(Course_12_Time == 9.30 && Course_12_Day == Tuesday){
    
    document.getElementById("Tuesday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}
else if(Course_12_Time == 10.30 && Course_12_Day == Tuesday){

    document.getElementById("Tuesday-10.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 11.30 && Course_12_Day == Tuesday){

    document.getElementById("Tuesday-11.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 12.30 && Course_12_Day == Tuesday){

    document.getElementById("Tuesday-12.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 1.30 && Course_12_Day == Tuesday){

    document.getElementById("Tuesday-1.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 2.30 && Course_12_Day == Tuesday){

    document.getElementById("Tuesday-2.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 3.30 && Course_12_Day == Tuesday){

    document.getElementById("Tuesday-3.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}









// Course_12 Wednessday  Conditions ========================================================

if(Course_12_Time == 9.30 && Course_12_Day == Wednessday){
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}


else if(Course_12_Time == 9.30 && Course_12_Day == Wednessday){
    
    document.getElementById("Wednessday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}
else if(Course_12_Time == 10.30 && Course_12_Day == Wednessday){

    document.getElementById("Wednessday-10.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 11.30 && Course_12_Day == Wednessday){

    document.getElementById("Wednessday-11.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 12.30 && Course_12_Day == Wednessday){

    document.getElementById("Wednessday-12.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 1.30 && Course_12_Day == Wednessday){

    document.getElementById("Wednessday-1.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 2.30 && Course_12_Day == Wednessday){

    document.getElementById("Wednessday-2.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 3.30 && Course_12_Day == Wednessday){

    document.getElementById("Wednessday-3.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}











// Course_12 Thursday  Conditions ========================================================

if(Course_12_Time == 9.30 && Course_12_Day == Thursday){
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}


else if(Course_12_Time == 9.30 && Course_12_Day == Thursday){
    
    document.getElementById("Thursday-9.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}
else if(Course_12_Time == 10.30 && Course_12_Day == Thursday){

    document.getElementById("Thursday-10.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 11.30 && Course_12_Day == Thursday){

    document.getElementById("Thursday-11.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 12.30 && Course_12_Day == Thursday){

    document.getElementById("Thursday-12.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 1.30 && Course_12_Day == Thursday){

    document.getElementById("Thursday-1.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 2.30 && Course_12_Day == Thursday){

    document.getElementById("Thursday-2.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}

else if(Course_12_Time == 3.30 && Course_12_Day == Thursday){

    document.getElementById("Thursday-3.30").innerHTML = 
    Course_12_Name + "<br><br>" + 
    Course_12_Teacher + "<br><br>" + 
    Course_12_RoomNo + "<hr>";
}


