version = 4;

Semester = 'Spring 2023';


//========  Course 1 ========================

Course_1_Name = "CSE-441- Computer Science & Engineering";  // Enter CourseName in here....
Course_1_Teacher = "Shakil";  // Enter Your Teacher's Name as a String "" ;
Course_1_Time = 2.30;           // Enter Class time as integer ;
Course_1_Day = "Saturday";      // Enter Class Day as String "" (Which day at your class? Please Enter) ;
Course_1_RoomNo = "AB-04 #503"; // Enter ClassRoom No : as string "";




//========  Course 2 ========================
Course_2_Name = "CSE 450 - Data Engineering";
Course_2_Teacher = "Saiful Islam Shakil";
Course_2_Time = 10.30;
Course_2_Day = "Monday";
Course_2_RoomNo = "AB 4 603";




//========  Course 3 ========================
Course_3_Name = null;
Course_3_Teacher = null;
Course_3_Time = null;
Course_3_Day = null;
Course_3_RoomNo = null;




//========  Course 4 ========================
Course_4_Name = null;
Course_4_Teacher = null;
Course_4_Time = null;
Course_4_Day = null;
Course_4_RoomNo = null;




//========  Course 5 ========================
Course_5_Name = null;
Course_5_Teacher = null;
Course_5_Time = null;
Course_5_Day = null;
Course_5_RoomNo = null;




//========  Course 6 ========================
Course_6_Name = null;
Course_6_Teacher = null;
Course_6_Time = null;
Course_6_Day = null;
Course_6_RoomNo = null;




//========  Course 7 ========================
Course_7_Name = null;
Course_7_Teacher = null;
Course_7_Time = null;
Course_7_Day = null;
Course_7_RoomNo = null;




//========  Course 8 ========================
Course_8_Name = null;
Course_8_Teacher = null;
Course_8_Time = null;
Course_8_Day = null;
Course_8_RoomNo = null;




//========  Course 9 ========================
Course_9_Name = null;
Course_9_Teacher = null;
Course_9_Time = null;
Course_9_Day = null;
Course_9_RoomNo = null;




//========  Course 10 ========================
Course_10_Name = null;
Course_10_Teacher = null;
Course_10_Time = null;
Course_10_Day = null;
Course_10_RoomNo = null;




//========  Course 11 ========================
Course_11_Name = null;
Course_11_Teacher = null;
Course_11_Time = null;
Course_11_Day = null;
Course_11_RoomNo = null;




//========  Course 12 ========================
Course_12_Name = null;
Course_12_Teacher = null;
Course_12_Time = null;
Course_12_Day = null;
Course_12_RoomNo = null;






Saturday = "Saturday";
Sunday = "Sunday";
Monday = "Monday";
Tuesday = "Tuesday";
Wednessday = "Wednessday";
Thursday = "Thursday";


////////////////////////////////////////////////

document.getElementById("version_id").innerHTML = version;
document.getElementById("sem_id").innerHTML = Semester;



//////////////////////////////////////////////////////////
/*
Developed by : MD. Saiful islam Shakil.
    B.Sc in CSE
    Daffodil international University - DIU.
    Batch 47.
    Faculty of Science & inforfation Technology- FSIT.
    
    Developed Time : Tuesday, May-30-2023
    Developed Reason : Just came in DIU library, Then in a time I realised, I need to make a routine.







*/



/////////